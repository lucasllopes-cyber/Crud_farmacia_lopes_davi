from flask import Flask, render_template, request, redirect
import psycopg2

app = Flask(__name__)

def ligar_banco():
    return psycopg2.connect(
        host="localhost",
        database="Farmacia",
        user="postgres",
        password="senai",
        port="5432"
    )

@app.route("/")
def inicio():
    return render_template("index.html")

@app.route("/remedios")
def remedios():
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute(
        "SELECT id, nome, laboratorio, estoque, preco "
        "FROM remedio ORDER BY id"
    )
    lista = cursor.fetchall()

    cursor.close()
    conexao.close()

    return render_template("remedios.html", remedios=lista)


@app.route("/remedios/enviar", methods=["POST"])
def enviar_remedio():
    nome = request.form["nome"]
    laboratorio = request.form["laboratorio"]
    estoque = request.form["estoque"]
    preco = request.form["preco"]

    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        INSERT INTO remedio (nome, laboratorio, estoque, preco)
        VALUES (%s, %s, %s, %s)
    """, (nome, laboratorio, estoque, preco))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/remedios")


@app.route("/remedios/editar/<int:id>")
def editar_remedio(id):
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        SELECT id, nome, laboratorio, estoque, preco
        FROM remedio WHERE id = %s
    """, (id,))

    remedio = cursor.fetchone()

    cursor.close()
    conexao.close()

    if remedio is None:
        return "Remedio nao encontrado", 404

    return render_template("editar_remedio.html", remedio=remedio)


@app.route("/remedios/atualizar/<int:id>", methods=["POST"])
def atualizar_remedio(id):
    nome = request.form["nome"]
    laboratorio = request.form["laboratorio"]
    estoque = request.form["estoque"]
    preco = request.form["preco"]

    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        UPDATE remedio
        SET nome = %s, laboratorio = %s,
            estoque = %s, preco = %s
        WHERE id = %s
    """, (nome, laboratorio, estoque, preco, id))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/remedios")


@app.route("/remedios/excluir/<int:id>", methods=["POST"])
def excluir_remedio(id):
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("DELETE FROM remedio WHERE id = %s", (id,))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/remedios")


@app.route("/clientes")
def clientes():
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        SELECT id, nome, telefone, idade, data_cadastro
        FROM cliente ORDER BY id
    """)
    lista = cursor.fetchall()

    cursor.close()
    conexao.close()

    return render_template("clientes.html", clientes=lista)


@app.route("/clientes/enviar", methods=["POST"])
def enviar_cliente():
    nome = request.form["nome"]
    telefone = request.form["telefone"]
    idade = request.form["idade"]
    data_cadastro = request.form["data_cadastro"]

    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        INSERT INTO cliente (nome, telefone, idade, data_cadastro)
        VALUES (%s, %s, %s, %s)
    """, (nome, telefone, idade, data_cadastro))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/clientes")


@app.route("/clientes/editar/<int:id>")
def editar_cliente(id):
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        SELECT id, nome, telefone, idade, data_cadastro
        FROM cliente WHERE id = %s
    """, (id,))

    cliente = cursor.fetchone()

    cursor.close()
    conexao.close()

    if cliente is None:
        return "Cliente nao encontrado", 404

    return render_template("editar_cliente.html", cliente=cliente)


@app.route("/clientes/atualizar/<int:id>", methods=["POST"])
def atualizar_cliente(id):
    nome = request.form["nome"]
    telefone = request.form["telefone"]
    idade = request.form["idade"]
    data_cadastro = request.form["data_cadastro"]

    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("""
        UPDATE cliente
        SET nome = %s, telefone = %s,
            idade = %s, data_cadastro = %s
        WHERE id = %s
    """, (nome, telefone, idade, data_cadastro, id))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/clientes")


@app.route("/clientes/excluir/<int:id>", methods=["POST"])
def excluir_cliente(id):
    conexao = ligar_banco()
    cursor = conexao.cursor()

    cursor.execute("DELETE FROM cliente WHERE id = %s", (id,))

    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect("/clientes")



if __name__ == '__main__':
    app.run()
